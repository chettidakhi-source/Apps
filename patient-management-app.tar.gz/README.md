# Patient Management App

This is a simple patient management web application built with Next.js and React.

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```
2. Run the development server:
   ```bash
   npm run dev
   ```
3. Open [http://localhost:3000](http://localhost:3000) in your browser to see the app.

## Features
- Add, edit, delete, and search patients
- Patient data is stored in localStorage
- Responsive and modern UI